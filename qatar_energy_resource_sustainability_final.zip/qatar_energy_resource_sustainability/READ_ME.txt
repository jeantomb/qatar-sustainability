QATAR — ENERGY & RESOURCE SUSTAINABILITY

Open index.html in Chrome or another modern browser. The website is self-contained;
its charts and navigation are built into the page. Internet access is only needed to
open external source links.

The content uses the research and chart data in the supplied Qatar Sustainability
Website Google Sites Build Pack. Check the cited original sources and update any
figures if your teacher requires newer data.

This is a standalone HTML website. Your assignment brief requires Google Sites,
so use this finished site as the content and design reference when recreating it
inside Google Sites. It cannot be imported into Google Sites as an editable site.
